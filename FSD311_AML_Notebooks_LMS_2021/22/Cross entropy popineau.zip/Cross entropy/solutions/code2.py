
avrg = 0.75 * b_log(1/0.75) + 0.25 * b_log(4)
print("On average, you will get "+str(round(avrg,2))+" bits of information from the weather station, every day.")