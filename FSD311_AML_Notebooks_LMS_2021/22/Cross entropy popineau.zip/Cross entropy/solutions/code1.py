
print("Respectively : "+str(b_log(4))+" and "+ str(round(b_log(1/0.75),2))+" bits of information are necessary.")