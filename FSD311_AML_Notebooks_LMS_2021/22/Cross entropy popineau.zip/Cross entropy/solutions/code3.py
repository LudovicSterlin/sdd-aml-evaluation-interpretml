
def entropy(forecast_list):
    entropy_sum = 0
    for i in range(len(forecast_list)):
        entropy_sum += forecast_list[i] * b_log(forecast_list[i])
    return -entropy_sum

entropy([0.35, 0.35, 0.10, 0.10, 0.04, 0.04, 0.01, 0.01])