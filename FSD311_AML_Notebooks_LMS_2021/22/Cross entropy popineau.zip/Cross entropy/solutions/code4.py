
def cross_entropy(true_distribution, forecasted_distribution):
    sum_cross_entropy = 0
    for i in range(len(true_distribution)):
        sum_cross_entropy += true_distribution[i] * forecasted_distribution[i]
    return sum_cross_entropy 

cross_entropy([0.35, 0.35, 0.10, 0.10, 0.04, 0.04, 0.01, 0.01], [2, 2, 3, 3, 4, 4, 5, 5])