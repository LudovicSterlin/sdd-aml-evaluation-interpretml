
# define classification data
p = [1, 1, 1, 1, 1, 0, 0, 0, 0, 0]
q = [0.8, 0.9, 0.9, 0.6, 0.8, 0.1, 0.4, 0.2, 0.1, 0.3]

# be careful as to which log we use here

def new_cross_entropy(true_distribution, forecasted_distribution) :
    sum_cross_entropy = 0
    for i in range(len(true_distribution)):
        sum_cross_entropy += true_distribution[i] * np.log(forecasted_distribution[i])
    return -sum_cross_entropy     

# calculate cross entropy for each example
results = list()
for i in range(len(p)):
# create the distribution for each event {0, 1}
    expected = [1.0 - p[i], p[i]]
    predicted = [1.0 - q[i], q[i]]
    # calculate cross entropy for the two events
    ce = new_cross_entropy(expected, predicted)
    print('>[y=%.1f, ypred=%.1f] ce: %.3f nats' % (p[i], q[i], ce))
    results.append(ce)

# calculate the average cross entropy
mean_ce = mean(results)
print('\n Average Cross Entropy: %.3f nats' % mean_ce)