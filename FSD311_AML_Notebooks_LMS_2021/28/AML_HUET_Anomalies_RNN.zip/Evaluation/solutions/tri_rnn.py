class TriRNN(nn.Module):
    
    def __init__(self, in_size, h_size, out_size):
        super(TriRNN, self).__init__()
        self.hidden_size = h_size
        self.rnn1 = nn.RNNCell(in_size, h_size)
        # Remarque : les cellules suivantes prennent en entrée la sortie des cellules précédentes
        self.rnn2 = nn.RNNCell(h_size, h_size)
        self.rnn3 = nn.RNNCell(h_size, h_size)
        self.linear = nn.Linear(h_size, out_size)

    def forward(self, input):

        h_t1 = torch.zeros(input.size(0), self.hidden_size, dtype=torch.double)
        h_t2 = torch.zeros(input.size(0), self.hidden_size, dtype=torch.double)
        h_t3 = torch.zeros(input.size(0), self.hidden_size, dtype=torch.double)
        out = []
        for x_t in input.split(1, dim=1):
            h_t1 = self.rnn1(x_t.squeeze(), h_t1)
            h_t2 = self.rnn2(h_t1, h_t2)
            h_t3 = self.rnn3(h_t2, h_t3)
            y_t = self.linear(h_t3).unsqueeze(1)
            out += [y_t]
        out = torch.cat(out, dim=1)
        return out, h_t