rel_err 
train_idx, test_idx = split_train_test(nsig, prop=0.6)

err_train = np.array(rel_err[train_idx])

clf = OneClassSVM(gamma='auto').fit(err_train)
clf.predict(rel_err)