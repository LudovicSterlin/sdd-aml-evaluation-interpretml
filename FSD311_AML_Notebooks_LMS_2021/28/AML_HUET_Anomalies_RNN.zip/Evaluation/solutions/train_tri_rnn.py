N_EPOCH = 10
BATCH_SIZE = 16

N_BATCH = int(nsig / BATCH_SIZE) + 1

# Initialisation du RNN et de l'optimiseur
rnn_3 = TriRNN(n_feat, n_hid, n_feat).double()
criterion = nn.MSELoss()
optimizer = optim.LBFGS(rnn_3.parameters(), lr=0.8)

# Séparation des jeux de données
idx_train , idx_test = split_train_test(nsig)

X_train = np.array(sig_data[idx_train])
X_test  = np.array(sig_data[idx_test])

x_inp = torch.from_numpy(X_train)

# Début des époques 
for j in range(N_EPOCH) : 
    
    for k in range(N_BATCH-1) :
        
        inp_batch = x_inp[k*BATCH_SIZE:(k+1)*BATCH_SIZE]  
        def closure():
            optimizer.zero_grad()
            out, _ = rnn_3(x_inp)
            loss = criterion(out[:, :-1,:], x_inp[:, 1:,:])
            print('Ecart moyen entre les prédictions et le signal:', loss.item())
            loss.backward()
            return loss
        optimizer.step(closure)

    # Le dernier lot est potentiellement plus petit, on le traite comme suite à la fin
    inp_batch = x_inp[(N_BATCH-1)*BATCH_SIZE:]
    
    def closure():
        optimizer.zero_grad()
        out, _ = rnn(x_inp)
        loss = criterion(out[:, :-1,:], x_inp[:, 1:,:])
        print('Ecart moyen entre les prédictions et le signal:', loss.item())
        loss.backward()
        return loss
    optimizer.step(closure)
                          
    np.random.shuffle(X_train)
    x_inp = torch.from_numpy(X_train)