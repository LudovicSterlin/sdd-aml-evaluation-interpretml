class SmallLSTM(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(SmallLSTM, self).__init__()
        self.lstm1 = nn.LSTMCell(input_size, hidden_size)
        self.lstm2 = nn.LSTMCell(hidden_size, hidden_size)
        self.lstm3 = nn.LSTMCell(hidden_size, hidden_size)
        self.lstm4 = nn.LSTMCell(hidden_size, hidden_size)
        self.lstm5 = nn.LSTMCell(hidden_size, hidden_size)
        self.linear = nn.Linear(hidden_size, output_size)
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size

    def forward(self, input):
        outputs = []
        h_t  = torch.zeros(input.size(0), self.hidden_size, dtype=torch.double)
        c_t  = torch.zeros(input.size(0), self.hidden_size, dtype=torch.double)
        h_t2 = torch.zeros(input.size(0), self.hidden_size, dtype=torch.double)
        c_t2 = torch.zeros(input.size(0), self.hidden_size, dtype=torch.double)
        h_t3 = torch.zeros(input.size(0), self.hidden_size, dtype=torch.double)
        c_t3 = torch.zeros(input.size(0), self.hidden_size, dtype=torch.double)
        h_t4 = torch.zeros(input.size(0), self.hidden_size, dtype=torch.double)
        c_t4 = torch.zeros(input.size(0), self.hidden_size, dtype=torch.double)
        h_t5 = torch.zeros(input.size(0), self.hidden_size, dtype=torch.double)
        c_t5 = torch.zeros(input.size(0), self.hidden_size, dtype=torch.double)

        for input_t in input.split(1, dim=1):
            h_t, c_t = self.lstm1(input_t, (h_t, c_t))
            h_t2, c_t2 = self.lstm2(h_t, (h_t2, c_t2))
            h_t3, c_t3 = self.lstm2(h_t, (h_t3, c_t3))
            h_t4, c_t4 = self.lstm2(h_t, (h_t4, c_t4))
            h_t5, c_t5 = self.lstm2(h_t, (h_t5, c_t5))
            output = self.linear(h_t5)
            outputs += [output]

        outputs = torch.cat(outputs, dim=1)
        return outputs


N_EPOCH = 10
BATCH_SIZE = 16

N_BATCH = int(nsig / BATCH_SIZE) + 1

# Initialisation du RNN et de l'optimiseur
small_net = SmallLSTM(n_feat, n_hid, n_feat).double()
criterion = nn.MSELoss()
optimizer = optim.LBFGS(rnn_3.parameters(), lr=0.8)

# Séparation des jeux de données
idx_train , idx_test = split_train_test(nsig, prop=0.6)

X_train = np.array(sig_data[idx_train])
X_test  = np.array(sig_data[idx_test])

x_inp = torch.from_numpy(X_train)

# Début des époques 
for j in range(N_EPOCH) : 

    print('Epoque :'+str(j)+' / '+str(N_EPOCH))

    for k in range(N_BATCH-1) :
        
        inp_batch = x_inp[k*BATCH_SIZE:(k+1)*BATCH_SIZE]  
        def closure():
            optimizer.zero_grad()
            out, _ = rnn_3(x_inp)
            loss = criterion(out[:, :-1,:], x_inp[:, 1:,:])
            loss.backward()
            return loss
        optimizer.step(closure)

    # Le dernier lot est potentiellement plus petit, on le traite comme suite à la fin
    inp_batch = x_inp[(N_BATCH-1)*BATCH_SIZE:]
    
    def closure():
        optimizer.zero_grad()
        out, _ = rnn(x_inp)
        loss = criterion(out[:, :-1,:], x_inp[:, 1:,:])
        loss.backward()
        return loss
    optimizer.step(closure)
                          
    np.random.shuffle(X_train)
    x_inp = torch.from_numpy(X_train)



sig_tensor = torch.from_numpy(np.array(sig_data))

with torch.no_grad():
    output, _ = smal_net(sig_tensor)
    y_out = output.detach().numpy()

    
# Si nous utilisons l'erreur relative, prenons une petite précaution de type "epsilon"
EPSILON = .8E-7

rel_err = np.zeros(nsig)

for k in range(nsig) :
    
    for l in range(n_feat) :
        
         rel_err[k] += np.sum( abs(sig_data[k, 1:,l] - y_out[k,:-1,l]) / ( abs(sig_data[k, t+1:,l]) + EPSILON ) )
    

fig, axs = plt.subplots(1, sharex=True, figsize=(18,15))

axs[0].plot(rel_err, color='b', marker='.')
axs[0].set_title('Erreur relative pour chaque fenêtre de mesure')
fig.tight_layout()