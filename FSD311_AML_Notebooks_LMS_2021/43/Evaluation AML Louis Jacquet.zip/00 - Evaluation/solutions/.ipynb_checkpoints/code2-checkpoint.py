plt.rcParams.update({'figure.figsize':(11,10), 'figure.dpi':120})

# Original Series
fig, axes = plt.subplots(2, 2)
plot_acf(df_exe_ns, ax=axes[0, 0], lags=len(df_exe_ns)-1)
plot_pacf(df_exe_ns, ax=axes[0, 1], lags=int(len(df_exe_ns)/2)-1)

# 1st Differencing
plot_acf(df_ns_diff1, ax=axes[1, 0], lags=len(df_ns_diff1)-1)
plot_pacf(df_ns_diff1, ax=axes[1, 1], lags=int(len(df_ns_diff1)/2)-1)

plt.show()

# The ACF of the 1st order differencing is very negative at lag 1 and the PACF has a big spike at lag 1 thus we can choose p = 1 and q = 1.