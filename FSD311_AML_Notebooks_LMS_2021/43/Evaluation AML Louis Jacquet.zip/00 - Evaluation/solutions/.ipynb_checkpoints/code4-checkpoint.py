# Forecast
fc, se, conf = model_fit.forecast(10, alpha=0.05)  # 95% conf

# Make as pandas series
index_forecast = pd.date_range(start='1904-01-01', end='1904-10-01', freq='MS')
fc_series = pd.Series(fc, index=index_forecast)
lower_series = pd.Series(conf[:, 0], index=index_forecast)
upper_series = pd.Series(conf[:, 1], index=index_forecast)

# Plot
plt.figure(figsize=(12,5), dpi=100)
plt.plot(df_exe_ns, label='actual')
plt.plot(fc_series, label='forecast')
plt.fill_between(lower_series.index, lower_series, upper_series, 
                 color='k', alpha=.15)
plt.title('Forecast for the next 10 months')
plt.legend(loc='upper left', fontsize=8)
plt.show()