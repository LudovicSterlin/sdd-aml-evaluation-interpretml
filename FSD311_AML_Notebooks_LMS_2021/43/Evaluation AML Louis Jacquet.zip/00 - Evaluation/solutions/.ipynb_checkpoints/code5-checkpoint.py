df_exe_se_diff = df_exe_se[:].diff(12).dropna()

# Original seasonal differenced series
fig, axes = plt.subplots(2, 2, figsize=(14,10))
plot_acf(df_exe_se_diff, ax=axes[0, 0], lags=40)
axes[0, 1].set(ylim=(-2,2))
plot_pacf(df_exe_se_diff, ax=axes[0, 1], lags=40)

# 1st Differencing of the seasonal differenced series
plot_acf(df_exe_se_diff.diff().dropna(), ax=axes[1, 0], lags=40)
plot_pacf(df_exe_se_diff.diff().dropna(), ax=axes[1, 1], lags=40)

plt.show()

# With the ACF plot of the original series, we deduct that d = 1. The spike at lag 1 for ACF implies q = 1. 
# It seems that we have 2 significant seasonal spikes for the PACF so let's try Q = 2. The spike at lag 1 for the PACF gives p = 1. 
# Thus we will try (p,d,q)=(1,1,1) / (P,D,Q)=(0,1,2) / m=12.