plt.rcParams.update({'figure.figsize':(9,10), 'figure.dpi':120})

# Original Series
fig, axes = plt.subplots(3, 2)
std = df_exe_ns.std()
axes[0, 0].plot(df_exe_ns); axes[0, 0].set_title(f'Original Series / std = {"{:.2f}".format(std)}')
plot_acf(df_exe_ns, ax=axes[0, 1], lags=len(df_exe_ns)-1)

# 1st Differencing
df_ns_diff1 = df_exe_ns.diff().dropna()
std_1 = df_ns_diff1.std()
axes[1, 0].plot(df_ns_diff1); axes[1, 0].set_title(f'1st Order Differencing / std = {"{:.2f}".format(std_1)}')
plot_acf(df_ns_diff1, ax=axes[1, 1], lags=len(df_ns_diff1)-1)

# 2nd Differencing
df_ns_diff2 = df_exe_ns.diff().diff().dropna()
std_2 = df_ns_diff2.std()
axes[2, 0].plot(df_ns_diff2); axes[2, 0].set_title(f'2nd Order Differencing / std = {"{:.2f}".format(std_2)}')
plot_acf(df_ns_diff2, ax=axes[2, 1], lags=len(df_ns_diff2)-1)

plt.show()


# We see that the original series is clearly not stationary. So we want to look at the 1st order differencing. We see that the
# 1st lag of the 1st differencing is very negative, so we will stop there. Besides, the standar deviation is minimum for the
# first order differencing. As we are sure that the original series is not stationary it might not be overdifferenced. Thus we take d = 1.