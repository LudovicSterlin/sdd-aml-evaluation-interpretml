# define model configuration
my_order = (0, 1, 2)
my_seasonal_order = (0, 1, 2, 12)
# define model
modelS = SARIMAX(df_exe_se, order=my_order, seasonal_order=my_seasonal_order)
modelS_fit = modelS.fit(disp=0)

# Forecast
n_periods = 24
fitted = modelS_fit.forecast(n_periods)

#get the confidence interval
forecast_S = modelS_fit.get_prediction(start=modelS.nobs,end=modelS.nobs+n_periods)
confint = forecast_S.conf_int(alpha=0.05)

index_of_fc = pd.date_range(df_exe_se.index[-1], periods = n_periods, freq='MS')

# make series for plotting purpose
fitted_series = pd.Series(fitted, index=index_of_fc)
lower_series = pd.Series(confint.iloc[:, 0], index=index_of_fc)
upper_series = pd.Series(confint.iloc[:, 1], index=index_of_fc)

# Plot
plt.plot(df_exe_se)
plt.plot(fitted_series, color='darkgreen')
plt.fill_between(lower_series.index, 
                 lower_series, 
                 upper_series, 
                 color='k', alpha=.15)

plt.title("SARIMA - Final Forecast for the number of air passengers")
plt.show()