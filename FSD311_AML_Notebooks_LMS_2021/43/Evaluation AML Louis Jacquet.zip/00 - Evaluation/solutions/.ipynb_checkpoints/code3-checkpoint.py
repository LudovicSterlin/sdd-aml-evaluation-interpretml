model = ARIMA(df_exe_ns, order=(1,1,1))
model_fit = model.fit(disp=0)
print(model_fit.summary())

plt.rcParams.update({'figure.figsize':(9,3), 'figure.dpi':120})

residuals = pd.DataFrame(model_fit.resid)
fig, ax = plt.subplots(1,2)
residuals.plot(title="Residuals", ax=ax[0])
residuals.plot(kind='kde', title='Density', ax=ax[1])
plt.show()

model_fit.plot_predict(dynamic=False)
plt.show()

# The model seems to be good regarding the AIC, the residuals and the fit.