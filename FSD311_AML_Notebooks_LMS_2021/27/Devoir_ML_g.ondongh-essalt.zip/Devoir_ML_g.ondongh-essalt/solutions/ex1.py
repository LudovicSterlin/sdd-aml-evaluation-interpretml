# define model
model_2 = Sequential()
model_2.add(Dense(50, input_dim=2, activation='relu', kernel_initializer='he_uniform'))
model_2.add(BatchNormalization())
model_2.add(Dense(1, activation='sigmoid'))
opt = SGD(lr=0.01, momentum=0.9)
model_2.compile(loss='binary_crossentropy', optimizer=opt, metrics=['accuracy'])
# fit model
history = model_2.fit(trainX, trainy, validation_data=(testX, testy), epochs=100, verbose=0)
# evaluate the model
_, train_acc = model_2.evaluate(trainX, trainy, verbose=0)
_, test_acc = model_2.evaluate(testX, testy, verbose=0)
print('Train: %.3f, Test: %.3f' % (train_acc, test_acc))
# plot history
plt.plot(history.history['accuracy'], label='train')
plt.plot(history.history['val_accuracy'], label='test')
plt.legend()
plt.show()