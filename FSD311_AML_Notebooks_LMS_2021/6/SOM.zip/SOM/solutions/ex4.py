def eta(t,eta_0,tau):
    return eta_0*np.exp(-t/tau)
def update_weights(som, input_vect, neuron_ind, winning_ind, epoch, eta_0, tau_eta, sigma_0, tau_sigma):
    for feature in range(som.shape[2]):
        som[neuron_ind][feature]+= eta(epoch, eta_0, tau_eta)*neighborhood(neuron_ind, winning_ind, epoch, sigma_0, tau_sigma)*(input_vect[feature]-som[neuron_ind][feature])
    return som