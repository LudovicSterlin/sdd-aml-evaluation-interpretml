def one_iter(data, som, epoch, eta_0, tau_eta, sigma_0, tau_sigma):
    # sampling:
    x = data.iloc[np.random.randint(0, len(data))]
    # competition
    win_neur = winning_neuron(som, x)
    for i in range(som.shape[0]):
        for j in range(som.shape[1]):
            # adaptation with integrated idea of cooperation
            update_weights(som,x,(i,j),win_neur,epoch, eta_0, tau_eta, sigma_0, tau_sigma)
    return som