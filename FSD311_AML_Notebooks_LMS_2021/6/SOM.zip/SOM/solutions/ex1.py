def rand_weights_som(x_size,y_size,dataset):
    nb_features = dataset.shape[1]
    random_seed = 4234
    rand_generator = np.random.RandomState(random_seed)
    som = rand_generator.rand(x_size,y_size,nb_features)
    return som

