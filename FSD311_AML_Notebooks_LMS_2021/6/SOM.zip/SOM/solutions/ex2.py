def winning_neuron(som, input_vect, verbose=False):
    winner_index = None
    smallest_dist = np.Inf
    for a in range(som.shape[0]):
        for b in range(som.shape[1]):
            dist = eucl_dist(input_vect,som[a,b])
            if verbose==True:
                print('Neuron index : ', (a,b), ', distance with input : ', dist)
                
            if  dist < smallest_dist:
                smallest_dist = dist
                winner_index = (a,b)
                if verbose==True:
                    print('   Current winning Neuron : ', (winner_index), ' with distance from input : ', smallest_dist)
    
    return winner_index