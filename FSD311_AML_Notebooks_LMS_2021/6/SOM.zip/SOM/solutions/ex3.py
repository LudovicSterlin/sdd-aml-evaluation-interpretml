def sigma(time, sigma_0, tau):
    return sigma_0 * np.exp(-time/tau)

def neighborhood(neuron_ind, winning_neuron_ind, epoch, sigma_0, tau_sigma):
    return np.exp(-lateral_dist(neuron_ind, winning_neuron_ind)**2/(2*sigma(epoch, sigma_0,tau_sigma)**2))
    