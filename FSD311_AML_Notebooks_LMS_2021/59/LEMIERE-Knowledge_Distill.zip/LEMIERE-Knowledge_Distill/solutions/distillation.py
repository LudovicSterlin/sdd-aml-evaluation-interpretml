# Créons un modèle student (a partir de la fonction réalisée plus haut)
student_model = stud_mod()

# On instancie puis on compile un distiller
distiller = Distiller(student=student_model, teacher=teacher)
distiller.compile(
    optimizer=keras.optimizers.Adam(),
    metrics=[keras.metrics.SparseCategoricalAccuracy()],
    student_loss_fn=keras.losses.SparseCategoricalCrossentropy(from_logits=True),
    distillation_loss_fn=keras.losses.KLDivergence(),
    alpha=0.1,
    temperature=10,
)

# Distillons:
distiller.fit(x_train, y_train, epochs=2)

# Evaluation
distiller.evaluate(x_test, y_test)
