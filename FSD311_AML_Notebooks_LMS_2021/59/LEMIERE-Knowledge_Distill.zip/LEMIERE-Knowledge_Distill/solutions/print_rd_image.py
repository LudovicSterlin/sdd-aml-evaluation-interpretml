n = np.random.randint(len(X_test))
plt.imshow(X_test[n])
print("Visualisation aléatoire d'une image dans le testset")
print(Y_test[n])
