teacher.evaluate(x_test, y_test)
