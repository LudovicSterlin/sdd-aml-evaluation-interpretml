preds=teacher(x_train)
plt.imshow(X_train[0])

print ("valeur du nombre :" +str(y_train[0]))

print("")
for T in range(1,50,5):
    print("Temperature = "+str(T))
    print(np.array(tf.nn.softmax(preds[0]/T)))
    print("")
