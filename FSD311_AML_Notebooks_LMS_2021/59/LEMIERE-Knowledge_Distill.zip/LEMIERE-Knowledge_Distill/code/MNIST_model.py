#Modele MNIST, basé sur un CNN. Fait à partir des solutions kaggle :
# https://www.kaggle.com/cdeotte/how-to-choose-cnn-architecture-mnist
# https://www.kaggle.com/c/digit-recognizer/discussion/61480

MNIST_model = keras.Sequential(
    [
        layers.Conv2D(32,kernel_size=5,padding='same',activation='relu',input_shape=(28,28,1)),
        layers.MaxPool2D(),
        layers.Dropout(0.4),
        layers.Conv2D(64,kernel_size=5,padding='same',activation='relu'),
        layers.MaxPool2D(),
        layers.Dropout(0.4),
        layers.Flatten(),
        layers.Dense(128, activation='relu'),
        layers.Dropout(0.4),
        layers.Dense(10),
    ],
    name="teacher",
)

    
MNIST_model.compile(
    optimizer=keras.optimizers.Adam(),
    loss=keras.losses.SparseCategoricalCrossentropy(from_logits=True),
    metrics=[keras.metrics.SparseCategoricalAccuracy()],
)

    
    
# Train and evaluate teacher on data.
MNIST_model.fit(x_train, y_train, epochs=30)
MNIST_model.evaluate(x_test, y_test)

MNIST_model.save('model/MNIST_model')
